let x;
let y;

function setup() {
  createCanvas(950, 950);
  x = random(200);
  x = int(x);
  y = random(200);
  y = int(y);
}

function draw() {
  background(270,255,30);
  let distanciaX;
  let distanciaY;
  let distancia;
  distanciaX = mouseX - x;
  distanciaY = mouseY - y;
  //distancia = sqrt(distanciaX*distanciaX + distanciaY*distanciaY);
  distancia = dist(mouseX,mouseY,x,y);
  circle(mouseX, mouseY, distancia);
  //circle(x, y, 10);
  //console.log(distancia);

  if (distancia < 3) {
    text("Encontrei Gabriel Delmenico!", 200, 200);
    noLoop();
  }
}